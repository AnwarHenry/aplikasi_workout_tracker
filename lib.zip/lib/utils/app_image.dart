class AppImage {
  static const String workoutTracker = "assets/images/workout.png";
  static const String iconGoogle = "assets/images/google.png";
}
